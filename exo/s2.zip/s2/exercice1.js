// Exercice 1: Somme des éléments d'un tableau
