// Exercice 8: Fusionner deux tableaux et supprimer les doublons
