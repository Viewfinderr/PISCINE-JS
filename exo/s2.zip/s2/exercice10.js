// Exercice 10: Convertir une chaîne de caractères en camelCase
