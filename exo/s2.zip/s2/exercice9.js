// Exercice 9: Calculer l'âge à partir d'une date de naissance
