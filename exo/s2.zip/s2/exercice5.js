// Exercice 5: Compter les occurrences d'une lettre dans une chaîne
