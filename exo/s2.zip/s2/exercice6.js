// Exercice 6: Trier un tableau de nombres
