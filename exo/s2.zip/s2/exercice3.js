// Exercice 3: Filtrer les nombres pairs d'un tableau
