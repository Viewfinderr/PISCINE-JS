// Exercice 4: Trouver un élément dans un tableau d'objets
