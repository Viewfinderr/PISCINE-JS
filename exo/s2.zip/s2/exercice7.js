// Exercice 7: Vérifier si un mot est un palindrome
