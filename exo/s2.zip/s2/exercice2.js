// Exercice 1: Trouver le plus grand nombre dans un tableau
