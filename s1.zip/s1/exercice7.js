// Exercice 7: Table de multiplication
