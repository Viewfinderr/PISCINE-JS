// Exercice 8: Recherche dans un tableau
