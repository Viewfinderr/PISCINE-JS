// Exercice 1: Afficher "Bonjour, monde!"
