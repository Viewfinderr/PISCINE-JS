// Exercice 6: Boucle for
