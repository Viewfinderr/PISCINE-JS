// Exercice 4: Vérifier si un nombre est pair ou impair
