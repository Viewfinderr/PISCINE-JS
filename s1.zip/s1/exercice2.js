// Exercice 2: Calculer la somme de deux nombres
