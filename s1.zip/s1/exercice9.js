// Exercice 9: Inverser une chaîne de caractères
