// Exercice 10: Calculer la factorielle d'un nombre
