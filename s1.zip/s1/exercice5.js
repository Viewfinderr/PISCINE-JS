// Exercice 5: Manipulation de chaînes de caractères
