// Exercice 3: Comparer deux nombres
